# Marine-Ecosystem-Health
러닝하며 바다 쓰레기를 줍고, 인증샷으로 학교끼리 랭킹 경쟁하는 앱
