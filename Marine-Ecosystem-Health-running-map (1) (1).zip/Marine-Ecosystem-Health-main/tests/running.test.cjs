const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

function app() {
  const elements = new Map(), watches = new Map();
  let now = 0, serial = 0, stored, storageFails = false;
  const el = () => ({ value: '', textContent: '', disabled: false, open: true, children: [], style: {},
    append(...items) { this.children.push(...items); }, replaceChildren(...items) { this.children = items; },
    setAttribute() {}, addEventListener() {}, showModal() { this.open = true; }, close() { this.open = false; } });
  const get = id => { if (!elements.has(id)) elements.set(id, el()); return elements.get(id); };
  const geo = { watchPosition(ok, fail) { const id = ++serial; watches.set(id, { ok, fail }); return id; }, clearWatch() {} };
  const context = vm.createContext({ document: { getElementById: get, createElement: el, querySelectorAll: () => [] },
    window: { addEventListener() {}, location: { protocol: 'http:' } }, navigator: { geolocation: geo },
    localStorage: { getItem: () => null, setItem(k, value) { if (storageFails) throw Error('quota'); stored = JSON.parse(value); } },
    crypto: { randomUUID: () => 'test-record' }, performance: { now: () => now },
    setInterval: () => 1, clearInterval() {}, setTimeout() {}, confirm: () => true, alert() {}, console });
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../app.js'), 'utf8'), context);
  return { get, eval: code => vm.runInContext(code, context), advance: ms => { now += ms; },
    latest: () => watches.get(serial), stored: () => stored, failStorage: () => { storageFails = true; },
    point(watch, lat, seconds) { watch.ok({ timestamp: Date.now() + seconds * 1000, coords: { latitude: lat, longitude: 129, accuracy: 5 } }); } };
}

test('pause freezes time, ignores stale GPS, and excludes travel during the pause', () => {
  const a = app(); a.get('run').onclick(); const first = a.latest();
  a.point(first, 35, 1); a.point(first, 35.0001, 11); a.advance(10000);
  const distance = a.eval('runDistance'); assert.ok(distance > 0);
  a.get('pauseRun').onclick(); assert.equal(a.eval('durationSeconds()'), 10);
  a.advance(60000); a.point(first, 35.1, 71);
  assert.equal(a.eval('route.length'), 2); assert.equal(a.eval('durationSeconds()'), 10);
  a.get('pauseRun').onclick(); const second = a.latest();
  a.point(first, 36, 72); a.point(second, 35.1, 72);
  assert.equal(a.eval('runDistance'), distance); assert.equal(a.eval('route.at(-1).segmentStart'), true);
  a.point(second, 35.1001, 82); a.advance(10000);
  assert.equal(a.eval('routeSegments(route).length'), 2);
  assert.ok(a.eval('runDistance') > distance); assert.equal(a.eval('durationSeconds()'), 20);
  a.get('endRun').onclick(); a.advance(20000); a.point(second, 36, 102);
  assert.equal(a.eval('durationSeconds()'), 20); assert.equal(a.eval('route.length'), 4);
  assert.equal(a.get('pauseRun').disabled, true);
});

test('saving persists duration and route, resets controls, and supports history maps without Leaflet', () => {
  const a = app(); a.get('run').onclick(); a.point(a.latest(), 35, 1); a.advance(12500);
  a.get('userName').value = '테스트'; a.get('school').value = '테스트학교'; a.get('bags').value = '1';
  a.eval("photo = 'data:image/jpeg;base64,test'; selectedAt = new Date().toISOString()");
  a.get('recordForm').onsubmit({ preventDefault() {} });
  assert.equal(a.stored().records[0].durationSeconds, 12); assert.equal(a.stored().records[0].route.length, 1);
  assert.equal(a.eval('runState'), 'idle'); assert.equal(a.get('runTime').textContent, '00:00:00');
  assert.equal(a.get('distance').readOnly, false);
  a.eval('showHistoryMap(records[0])'); assert.match(a.get('routeSummary').textContent, /00:00:12/);
  a.eval('delete records[0].durationSeconds; showHistoryMap(records[0])');
  assert.match(a.get('routeSummary').textContent, /활동 시간 미기록/);
});

test('GPS denial pauses timer; temporary GPS loss keeps the session recoverable', () => {
  const a = app(); a.get('run').onclick(); a.advance(3000);
  a.latest().fail({ code: 3 }); assert.equal(a.eval('runState'), 'running');
  a.latest().fail({ code: 1 }); a.advance(9000);
  assert.equal(a.eval('runState'), 'paused'); assert.equal(a.eval('durationSeconds()'), 3);
  assert.equal(a.get('pauseRun').textContent, '러닝 재개');
});

test('failed storage keeps the unsaved run and timer intact', () => {
  const a = app(); a.get('run').onclick(); a.point(a.latest(), 35, 1); a.advance(5000);
  a.get('userName').value = '테스트'; a.get('school').value = '학교'; a.get('bags').value = '1';
  a.eval("photo = 'data:image/jpeg;base64,test'"); a.failStorage();
  a.get('recordForm').onsubmit({ preventDefault() {} });
  assert.equal(a.eval('runState'), 'running'); assert.equal(a.eval('route.length'), 1);
  assert.match(a.get('formStatus').textContent, /저장 공간/);
});

test('map draws separate pause segments, start/end markers, and route bounds', () => {
  const a = app();
  a.eval(`
    var drawn = [], markers = [], bounds;
    var L = {
      map: () => ({ setView() { return this; }, invalidateSize() {}, fitBounds(b) { bounds = b; } }),
      layerGroup: () => ({ addTo() { return this; }, clearLayers() {} }),
      tileLayer: () => ({ on() { return this; }, addTo() { return this; } }),
      polyline: points => ({ addTo() { drawn.push(points); return this; } }),
      circleMarker: point => ({ bindTooltip() { markers.push(point); return this; }, addTo() { return this; } }),
      latLngBounds: points => points
    };
    window.L = L;
    var view = createRouteMap('runMap', 'mapStatus');
    drawRoute(view, [{lat:35,lng:129,segmentStart:true},{lat:35.001,lng:129},{lat:36,lng:129,segmentStart:true},{lat:36.001,lng:129}], true);
  `);
  assert.equal(a.eval('drawn.length'), 2); assert.equal(a.eval('drawn[0].length'), 2);
  assert.equal(a.eval('drawn[1][0][0]'), 36); assert.equal(a.eval('markers.length'), 2);
  assert.equal(a.eval('bounds.length'), 4);
});
